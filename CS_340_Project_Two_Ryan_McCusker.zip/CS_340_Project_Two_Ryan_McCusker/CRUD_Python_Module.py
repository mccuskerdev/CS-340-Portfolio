# Python module for CRUD operations on the AAC MongoDB database
from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        # Initializing the MongoClient to access the MongoDB
        # databases and collections. Hard-wired to use the aac
        # database, the animals collection, and the aacuser account.
        USER = 'aacuser'
        PASS = 'aacuser123'
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

    def create(self, data):
        """ Insert a document into the animals collection.
            Input: data (dict) - key/value pairs to insert
            Returns: True if successful, False otherwise
        """
        if data is not None:
            try:
                self.database.animals.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred during insert: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """ Query documents from the animals collection.
            Input: query (dict) - key/value lookup pair
            Returns: list of results if successful, empty list otherwise
        """
        if query is not None:
            try:
                cursor = self.database.animals.find(query)
                return list(cursor)
            except Exception as e:
                print(f"An error occurred during read: {e}")
                return []
        else:
            return []

    def update(self, query, update_data):
        """ Update document(s) in the animals collection.
            Input: query (dict) - key/value lookup pair to find documents
                   update_data (dict) - key/value pairs to update
            Returns: number of objects modified in the collection
        """
        if query is not None and update_data is not None:
            try:
                result = self.database.animals.update_many(query, {"$set": update_data})
                return result.modified_count
            except Exception as e:
                print(f"An error occurred during update: {e}")
                return 0
        else:
            raise Exception("Query and update data parameters cannot be empty")

    def delete(self, query):
        """ Remove document(s) from the animals collection.
            Input: query (dict) - key/value lookup pair to find documents
            Returns: number of objects removed from the collection
        """
        if query is not None:
            try:
                result = self.database.animals.delete_many(query)
                return result.deleted_count
            except Exception as e:
                print(f"An error occurred during delete: {e}")
                return 0
        else:
            raise Exception("Query parameter cannot be empty")